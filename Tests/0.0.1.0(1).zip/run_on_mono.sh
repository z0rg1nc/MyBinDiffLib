#!/bin/bash
mono ./BitMoneyClient.exe --use-mono=1 $@